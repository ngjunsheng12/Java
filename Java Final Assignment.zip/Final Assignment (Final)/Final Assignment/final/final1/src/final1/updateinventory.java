/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package final1;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ASUS
 */
public class updateinventory extends javax.swing.JFrame {


    public updateinventory() {
        initComponents();
        getContentPane().setBackground(Color.pink);

    try {
        loadTableDataFromItem(); 
    } catch (IOException ex) {
        Logger.getLogger(updateinventory.class.getName()).log(Level.SEVERE, null, ex);
    }

    jTable1.getSelectionModel().addListSelectionListener(event -> {
        if (!event.getValueIsAdjusting() && jTable1.getSelectedRow() != -1) {
            int selectedRow = jTable1.getSelectedRow();
            jTextField1.setText(jTable1.getValueAt(selectedRow, 0).toString());
            jTextField2.setText(jTable1.getValueAt(selectedRow, 1).toString()); 
            jTextField3.setText(jTable1.getValueAt(selectedRow, 2).toString());
        }
    });
        
    try {
        loadTableDataFromHospitals();
    } catch (IOException ex) {
        Logger.getLogger(updateinventory.class.getName()).log(Level.SEVERE, null, ex);
    }

    jTable2.getSelectionModel().addListSelectionListener(event -> {
        if (!event.getValueIsAdjusting() && jTable2.getSelectedRow() != -1) {
            int selectedRow = jTable2.getSelectedRow();
            jTextField3.setText(jTable2.getValueAt(selectedRow, 0).toString());
            }
    });
     
    try {
        loadTableDataFromTransaction(); 
    } catch (IOException ex) {
        Logger.getLogger(updateinventory.class.getName()).log(Level.SEVERE, null, ex);
    }

    jTable3.getSelectionModel().addListSelectionListener(event -> {
        if (!event.getValueIsAdjusting() && jTable3.getSelectedRow() != -1) {

            }
    });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel10 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Update Inventory");

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setText("ITEM INVENTORY UPDATE");

        jLabel2.setText("Item Code :");

        jButton1.setText("Update Inventory");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel3.setText("Partner ID :");

        jLabel5.setText("Quantity (Boxes) :");

        jButton4.setText("Back to Inventory Mangement");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton3.setText("Clear All");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item Code", "Item Name", "Supplier ID", "Quantity (Boxes)"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton2.setText("Search");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel6.setText("Search :");

        jLabel4.setText("Item Name :");

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Transaction ID", "Item Code", "Item Name", "Partner ID", "Quantity (Boxes)", "Date-time"
            }
        ));
        jScrollPane2.setViewportView(jTable3);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Hospital ID", "Hospital Name", "Address"
            }
        ));
        jScrollPane3.setViewportView(jTable2);

        jSeparator1.setForeground(java.awt.Color.black);

        jLabel10.setText("Total Received :");

        jLabel11.setText("Total Distributed :");

        jButton5.setText("Clear All");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator1)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 50, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton4)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1147, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35))
            .addGroup(layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTextField1)
                                    .addComponent(jTextField3, javax.swing.GroupLayout.DEFAULT_SIZE, 171, Short.MAX_VALUE))
                                .addGap(30, 30, 30)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTextField4)
                                    .addComponent(jTextField2, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(40, 40, 40)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(62, 62, 62)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 535, Short.MAX_VALUE)
                            .addComponent(jScrollPane3))
                        .addGap(33, 33, 33))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(29, 29, 29))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(29, 29, 29)
                                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)))
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGap(423, 423, 423)
                .addComponent(jLabel10)
                .addGap(18, 18, 18)
                .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(96, 96, 96)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(127, 127, 127)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(39, 39, 39)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel6)
                        .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton5)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 72, Short.MAX_VALUE)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        setSize(new java.awt.Dimension(1243, 886));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        jTable1.clearSelection();
        jTable1.setRowSorter(null);
        jTable2.clearSelection();
        jTable2.setRowSorter(null);
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        this.dispose();
        managementinventory obj = new managementinventory();
        obj.setLocationRelativeTo(null);
        obj.setVisible(true);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

    DefaultTableModel model = (DefaultTableModel) jTable3.getModel();

    String itemcode = jTextField1.getText();
    String itemname = jTextField2.getText();
    String partnerid = jTextField3.getText();
    String quantityboxes = jTextField4.getText();

    if (itemcode.isEmpty() || itemname.isEmpty() || partnerid.isEmpty() || quantityboxes.isEmpty()) {
        JOptionPane.showMessageDialog(rootPane, "Please fill in all text fields before saving.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(rootPane, "Are you sure you want to save this item?", "Confirm Save", JOptionPane.YES_NO_OPTION);
    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    int qtyBoxes;
    try {
        qtyBoxes = Integer.parseInt(quantityboxes);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(rootPane, "Invalid quantity. Please enter a number.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    int updatedQuantity = 0;
    java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("dd/MM/yy h.mma");
    String dateTime = dateFormat.format(new java.util.Date());

    String lastTransactionId = "T00";
    try (BufferedReader reader = new BufferedReader(new FileReader("src\\final1\\transaction.txt"))) {
        String lastLine = null, line;
        while ((line = reader.readLine()) != null) {
            lastLine = line;
        }
        if (lastLine != null) {
            String[] lastTransactionData = lastLine.split(", ");
            lastTransactionId = lastTransactionData[0];
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(rootPane, "Error reading transaction file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (lastTransactionId.length() > 1) {
        int lastIdNumber = Integer.parseInt(lastTransactionId.substring(1));
        lastTransactionId = "T" + String.format("%02d", lastIdNumber + 1);
    } else {
        lastTransactionId = "T01"; 
    }
    String transactionid = lastTransactionId;

    try {
        List<String> fileContent = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader("src\\final1\\ppe.txt"));
        String line;

        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(", ");
            if (parts[0].equals(itemcode)) {
                int currentQuantity = Integer.parseInt(parts[3]);

                if (partnerid.startsWith("S")) { 
                    updatedQuantity = currentQuantity + qtyBoxes; 
                } else if (partnerid.startsWith("H")) {
                    updatedQuantity = currentQuantity - qtyBoxes;
                }

                if (updatedQuantity < 0) {
                    JOptionPane.showMessageDialog(rootPane, "Quantity cannot be negative.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                parts[3] = String.valueOf(updatedQuantity); 
                fileContent.add(String.join(", ", parts)); 
            } else {
                fileContent.add(line); 
            }
        }
        reader.close();

        try (FileWriter writer = new FileWriter("src\\final1\\ppe.txt")) {
            for (String updatedLine : fileContent) {
                writer.write(updatedLine + System.lineSeparator());
            }
        }

        try (FileWriter writer = new FileWriter("src\\final1\\transaction.txt", true)) {
            writer.write(transactionid + ", " + itemcode + ", " + itemname + ", " + partnerid + ", " + quantityboxes + ", " + dateTime);
            writer.write(System.lineSeparator());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(rootPane, "Error saving transaction: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JOptionPane.showMessageDialog(rootPane, "Saved and updated item successfully", "Success", JOptionPane.INFORMATION_MESSAGE);

        loadTableDataFromItem();
        loadTableDataFromTransaction();

        jTable1.clearSelection();
        jTable2.clearSelection();
        jTable3.clearSelection();
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField4.setText("");

    } catch (Exception e) {
        JOptionPane.showMessageDialog(rootPane, "Error updating PPE file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        String searchtext = jTextField5.getText();

        if (searchtext.isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Please fill in the search text field before searching.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(rootPane, "Do you sure want to search?", "Confirm Search", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        // Clear previous results
        DefaultTableModel model = (DefaultTableModel) jTable3.getModel();
        model.setRowCount(0);
        jTextField6.setText("");
        jTextField7.setText("");

        String itemCode = searchtext.trim();
        int totalReceived = 0;
        int totalDistributed = 0;

        // Read from transaction.txt
        try (BufferedReader reader = new BufferedReader(new FileReader("src\\final1\\transaction.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(", ");
                if (parts.length >= 5 && parts[1].equals(itemCode)) {
                    int quantity = Integer.parseInt(parts[4]);

                    if (parts[3].startsWith("S")) {
                        totalReceived += quantity; 
                    } else if (parts[3].startsWith("H")) {
                        totalDistributed += quantity; 
                    }

                    // Add row to jTable3
                    model.addRow(new Object[]{parts[0], parts[1], parts[2], parts[3], quantity, parts[5]});
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(rootPane, "Error reading transaction file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        jTextField6.setText(String.valueOf(totalReceived)); 
        jTextField7.setText(String.valueOf(totalDistributed)); 

        if (model.getRowCount() == 0) {
            JOptionPane.showMessageDialog(rootPane, "No matches found for the item code: " + itemCode, "No Results", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(rootPane, "Found " + model.getRowCount() + " matches for item code: " + itemCode, "Results Found", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

    jTable3.clearSelection();
    jTable3.setRowSorter(null);
    jTextField5.setText("");
    jTextField6.setText("");
    jTextField7.setText("");

    DefaultTableModel model = (DefaultTableModel) jTable3.getModel();
    model.setRowCount(0); 

    try (BufferedReader reader = new BufferedReader(new FileReader("src\\final1\\transaction.txt"))) {
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(", ");
            if (parts.length >= 6) { 
                // Add row to jTable3
                model.addRow(new Object[]{parts[0], parts[1], parts[2], parts[3], Integer.parseInt(parts[4]), parts[5]}); 
            }
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(rootPane, "Error reading transaction file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    JOptionPane.showMessageDialog(rootPane, "All transactions have been loaded.", "Load Complete", JOptionPane.INFORMATION_MESSAGE);

    }//GEN-LAST:event_jButton5ActionPerformed

    private void loadTableDataFromItem() throws IOException {
    String filepath = "src\\final1\\ppe.txt";

    try (BufferedReader br = new BufferedReader(new FileReader(filepath))) {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

        model.setRowCount(0);

        String line;
        while ((line = br.readLine()) != null) {
            String[] dataRow = line.trim().split(",\\s*");
            if (dataRow.length == 4) {
                model.addRow(dataRow); 
            }
        }
    } catch (FileNotFoundException ex) {
        Logger.getLogger(updateinventory.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(rootPane, "File not found: " + filepath);
    } catch (IOException ex) {
        Logger.getLogger(updateinventory.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(rootPane, "Error reading file: " + filepath);
    }

    jTable1.addFocusListener(new java.awt.event.FocusAdapter() {
        @Override
        public void focusLost(java.awt.event.FocusEvent evt) {
            jTable1.clearSelection();
        }
    });

    jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
        @Override
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            if (!jTable1.hasFocus()) {
                jTable1.requestFocus();
            }
        }
    });
}
    
    private void loadTableDataFromHospitals() throws IOException {
    String filepath = "src\\final1\\hospitals.txt";

    try (BufferedReader br = new BufferedReader(new FileReader(filepath))) {
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();

        model.setRowCount(0);

        String line;
        while ((line = br.readLine()) != null) {
            String[] dataRow = line.trim().split(",\\s*");
            if (dataRow.length == 3) {
                model.addRow(dataRow);
            }
        }
    } catch (FileNotFoundException ex) {
        Logger.getLogger(updateinventory.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(rootPane, "File not found: " + filepath);
    } catch (IOException ex) {
        Logger.getLogger(updateinventory.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(rootPane, "Error reading file: " + filepath);
    }

    jTable2.addFocusListener(new java.awt.event.FocusAdapter() {
        @Override
        public void focusLost(java.awt.event.FocusEvent evt) {
            jTable2.clearSelection();
        }
    });

    jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
        @Override
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            if (!jTable2.hasFocus()) {
                jTable2.requestFocus();
            }
        }
    });
}
    
    private void loadTableDataFromTransaction() throws IOException {
    String filepath = "src\\final1\\transaction.txt";

    try (BufferedReader br = new BufferedReader(new FileReader(filepath))) {
        DefaultTableModel model = (DefaultTableModel) jTable3.getModel();

        model.setRowCount(0);

        String line;
        while ((line = br.readLine()) != null) {
            String[] dataRow = line.trim().split(",\\s*");
            if (dataRow.length == 6) {
                model.addRow(dataRow); 
            }
        }
    } catch (FileNotFoundException ex) {
        Logger.getLogger(updateinventory.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(rootPane, "File not found: " + filepath);
    } catch (IOException ex) {
        Logger.getLogger(updateinventory.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(rootPane, "Error reading file: " + filepath);
    }

    jTable3.addFocusListener(new java.awt.event.FocusAdapter() {
        @Override
        public void focusLost(java.awt.event.FocusEvent evt) {
            jTable3.clearSelection();
        }
    });

    jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
        @Override
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            if (!jTable3.hasFocus()) {
                jTable3.requestFocus();
            }
        }
    });
}
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
       java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                updateinventory obj = new updateinventory();
                obj.setLocationRelativeTo(null);
                obj.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    // End of variables declaration//GEN-END:variables
}
